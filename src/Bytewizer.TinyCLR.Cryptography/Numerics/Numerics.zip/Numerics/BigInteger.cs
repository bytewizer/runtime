﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

//https://github.com/dotnet/runtime/blob/f3b55355d69893339ac6b42a17af4fcd5b196464/src/libraries/System.Runtime.Numerics/src/System/Numerics/BigInteger.cs

using System;
using System.Diagnostics;
using System.Globalization;

namespace Bytewizer.TinyCLR.Numerics
{
    public struct BigInteger
    {
        private const int knMaskHighBit = int.MinValue;
        private const uint kuMaskHighBit = unchecked((uint)int.MinValue);
        private const int kcbitUint = 32;
        private const int kcbitUlong = 64;
        private const int DecimalScaleFactorMask = 0x00FF0000;
        private const int DecimalSignMask = unchecked((int)0x80000000);

        // For values int.MinValue < n <= int.MaxValue, the value is stored in sign
        // and _bits is null. For all other values, sign is +1 or -1 and the bits are in _bits
        internal readonly int _sign; // Do not rename (binary serialization)
        internal readonly uint[] _bits; // Do not rename (binary serialization)

        // We have to make a choice of how to represent int.MinValue. This is the one
        // value that fits in an int, but whose negation does not fit in an int.
        // We choose to use a large representation, so we're symmetric with respect to negation.
        private static readonly BigInteger s_bnMinInt = new BigInteger(-1, new uint[] { kuMaskHighBit });
        private static readonly BigInteger s_bnOneInt = new BigInteger(1);
        private static readonly BigInteger s_bnZeroInt = new BigInteger(0);
        private static readonly BigInteger s_bnMinusOneInt = new BigInteger(-1);

        public BigInteger(int value)
        {
            if (value == int.MinValue)
                this = s_bnMinInt;
            else
            {
                _sign = value;
                _bits = null;
            }
            AssertValid();
        }

        public BigInteger(uint value)
        {
            if (value <= int.MaxValue)
            {
                _sign = (int)value;
                _bits = null;
            }
            else
            {
                _sign = +1;
                _bits = new uint[1];
                _bits[0] = value;
            }
            AssertValid();
        }

        public BigInteger(long value)
        {
            if (int.MinValue < value && value <= int.MaxValue)
            {
                _sign = (int)value;
                _bits = null;
            }
            else if (value == int.MinValue)
            {
                this = s_bnMinInt;
            }
            else
            {
                ulong x = 0;
                if (value < 0)
                {
                    x = unchecked((ulong)-value);
                    _sign = -1;
                }
                else
                {
                    x = (ulong)value;
                    _sign = +1;
                }

                if (x <= uint.MaxValue)
                {
                    _bits = new uint[1];
                    _bits[0] = (uint)x;
                }
                else
                {
                    _bits = new uint[2];
                    _bits[0] = unchecked((uint)x);
                    _bits[1] = (uint)(x >> kcbitUint);
                }
            }

            AssertValid();
        }

        public BigInteger(ulong value)
        {
            if (value <= int.MaxValue)
            {
                _sign = (int)value;
                _bits = null;
            }
            else if (value <= uint.MaxValue)
            {
                _sign = +1;
                _bits = new uint[1];
                _bits[0] = (uint)value;
            }
            else
            {
                _sign = +1;
                _bits = new uint[2];
                _bits[0] = unchecked((uint)value);
                _bits[1] = (uint)(value >> kcbitUint);
            }

            AssertValid();
        }

        public BigInteger(byte[] value)
        {
            if (value == null)
                throw new ArgumentNullException(nameof(value));
            //Contract.EndContractBlock();

            int byteCount = value.Length;
            bool isNegative = byteCount > 0 && ((value[byteCount - 1] & 0x80) == 0x80);

            // Try to conserve space as much as possible by checking for wasted leading byte[] entries 
            while (byteCount > 0 && value[byteCount - 1] == 0) byteCount--;

            if (byteCount == 0)
            {
                // BigInteger.Zero
                _sign = 0;
                _bits = null;
                AssertValid();
                return;
            }

            if (byteCount <= 4)
            {
                if (isNegative)
                    _sign = unchecked((int)0xffffffff);
                else
                    _sign = 0;
                for (int i = byteCount - 1; i >= 0; i--)
                {
                    _sign <<= 8;
                    _sign |= value[i];
                }
                _bits = null;

                if (_sign < 0 && !isNegative)
                {
                    // Int32 overflow
                    // Example: Int64 value 2362232011 (0xCB, 0xCC, 0xCC, 0x8C, 0x0)
                    // can be naively packed into 4 bytes (due to the leading 0x0)
                    // it overflows into the int32 sign bit
                    _bits = new uint[1];
                    _bits[0] = unchecked((uint)_sign);
                    _sign = +1;
                }
                if (_sign == int.MinValue)
                    this = s_bnMinInt;
            }
            else
            {
                int unalignedBytes = byteCount % 4;
                int dwordCount = byteCount / 4 + (unalignedBytes == 0 ? 0 : 1);
                bool isZero = true;
                uint[] val = new uint[dwordCount];

                // Copy all dwords, except but don't do the last one if it's not a full four bytes
                int curDword, curByte, byteInDword;
                curByte = 3;
                for (curDword = 0; curDword < dwordCount - (unalignedBytes == 0 ? 0 : 1); curDword++)
                {
                    byteInDword = 0;
                    while (byteInDword < 4)
                    {
                        if (value[curByte] != 0x00) isZero = false;
                        val[curDword] <<= 8;
                        val[curDword] |= value[curByte];
                        curByte--;
                        byteInDword++;
                    }
                    curByte += 8;
                }

                // Copy the last dword specially if it's not aligned
                if (unalignedBytes != 0)
                {
                    if (isNegative) val[dwordCount - 1] = 0xffffffff;
                    for (curByte = byteCount - 1; curByte >= byteCount - unalignedBytes; curByte--)
                    {
                        if (value[curByte] != 0x00) isZero = false;
                        val[curDword] <<= 8;
                        val[curDword] |= value[curByte];
                    }
                }

                if (isZero)
                {
                    this = s_bnZeroInt;
                }
                else if (isNegative)
                {
                    NumericsHelpers.DangerousMakeTwosComplement(val); // Mutates val

                    // Pack _bits to remove any wasted space after the twos complement
                    int len = val.Length;
                    while (len > 0 && val[len - 1] == 0)
                        len--;
                    if (len == 1 && unchecked((int)(val[0])) > 0)
                    {
                        if (val[0] == 1 /* abs(-1) */)
                        {
                            this = s_bnMinusOneInt;
                        }
                        else if (val[0] == kuMaskHighBit /* abs(Int32.MinValue) */)
                        {
                            this = s_bnMinInt;
                        }
                        else
                        {
                            _sign = (-1) * ((int)val[0]);
                            _bits = null;
                        }
                    }
                    else if (len != val.Length)
                    {
                        _sign = -1;
                        _bits = new uint[len];
                        Array.Copy(val, 0, _bits, 0, len);
                    }
                    else
                    {
                        _sign = -1;
                        _bits = val;
                    }
                }
                else
                {
                    _sign = +1;
                    _bits = val;
                }
            }
            AssertValid();
        }

        internal BigInteger(int n, uint[] rgu)
        {
            _sign = n;
            _bits = rgu;
            AssertValid();
        }

        internal BigInteger(uint[] value, bool negative)
        {
            if (value == null)
                throw new ArgumentNullException(nameof(value));
            //Contract.EndContractBlock();

            int len;

            // Try to conserve space as much as possible by checking for wasted leading uint[] entries 
            // sometimes the uint[] has leading zeros from bit manipulation operations & and ^
            for (len = value.Length; len > 0 && value[len - 1] == 0; len--) ;

            if (len == 0)
                this = s_bnZeroInt;
            // Values like (Int32.MaxValue+1) are stored as "0x80000000" and as such cannot be packed into _sign
            else if (len == 1 && value[0] < kuMaskHighBit)
            {
                _sign = (negative ? -(int)value[0] : (int)value[0]);
                _bits = null;
                // Although Int32.MinValue fits in _sign, we represent this case differently for negate
                if (_sign == int.MinValue)
                    this = s_bnMinInt;
            }
            else
            {
                _sign = negative ? -1 : +1;
                _bits = new uint[len];
                Array.Copy(value, 0, _bits, 0, len);
            }
            AssertValid();
        }

        public static BigInteger Zero { get { return s_bnZeroInt; } }

        public bool IsEven { get { AssertValid(); return _bits == null ? (_sign & 1) == 0 : (_bits[0] & 1) == 0; } }

        public int Sign
        {
            get { AssertValid(); return (_sign >> (kcbitUint - 1)) - (-_sign >> (kcbitUint - 1)); }
        }

        public static BigInteger Abs(BigInteger value)
        {
            return (value >= Zero) ? value : -value;
        }

        public int CompareTo(BigInteger other)
        {
            AssertValid();
            other.AssertValid();

            if ((_sign ^ other._sign) < 0)
            {
                // Different signs, so the comparison is easy.
                return _sign < 0 ? -1 : +1;
            }

            // Same signs
            if (_bits == null)
            {
                if (other._bits == null)
                    return _sign < other._sign ? -1 : _sign > other._sign ? +1 : 0;
                return -other._sign;
            }
            int cuThis, cuOther;
            if (other._bits == null || (cuThis = _bits.Length) > (cuOther = other._bits.Length))
                return _sign;
            if (cuThis < cuOther)
                return -_sign;

            int cuDiff = GetDiffLength(_bits, other._bits, cuThis);
            if (cuDiff == 0)
                return 0;
            return _bits[cuDiff - 1] < other._bits[cuDiff - 1] ? -_sign : _sign;
        }

        public static bool operator <=(BigInteger left, BigInteger right)
        {
            return left.CompareTo(right) <= 0;
        }

        public static bool operator >=(BigInteger left, BigInteger right)
        {
            return left.CompareTo(right) >= 0;
        }

        public static BigInteger operator -(BigInteger value)
        {
            value.AssertValid();
            return new BigInteger(-value._sign, value._bits);
        }

        public static implicit operator BigInteger(long value)
        {
            return new BigInteger(value);
        }

        public static BigInteger ModPow(BigInteger value, BigInteger exponent, BigInteger modulus)
        {
            if (exponent.Sign < 0)
                throw new ArgumentOutOfRangeException(nameof(exponent), "SR.ArgumentOutOfRange_MustBeNonNeg");
            //Contract.EndContractBlock();

            value.AssertValid();
            exponent.AssertValid();
            modulus.AssertValid();

            bool trivialValue = value._bits == null;
            bool trivialExponent = exponent._bits == null;
            bool trivialModulus = modulus._bits == null;

            if (trivialModulus)
            {
                uint bits = trivialValue && trivialExponent ? BigIntegerCalculator.Pow(NumericsHelpers.Abs(value._sign), NumericsHelpers.Abs(exponent._sign), NumericsHelpers.Abs(modulus._sign)) :
                            trivialValue ? BigIntegerCalculator.Pow(NumericsHelpers.Abs(value._sign), exponent._bits, NumericsHelpers.Abs(modulus._sign)) :
                            trivialExponent ? BigIntegerCalculator.Pow(value._bits, NumericsHelpers.Abs(exponent._sign), NumericsHelpers.Abs(modulus._sign)) :
                            BigIntegerCalculator.Pow(value._bits, exponent._bits, NumericsHelpers.Abs(modulus._sign));

                return value._sign < 0 && !exponent.IsEven ? -1 * bits : bits;
            }
            else
            {
                uint[] bits = trivialValue && trivialExponent ? BigIntegerCalculator.Pow(NumericsHelpers.Abs(value._sign), NumericsHelpers.Abs(exponent._sign), modulus._bits) :
                              trivialValue ? BigIntegerCalculator.Pow(NumericsHelpers.Abs(value._sign), exponent._bits, modulus._bits) :
                              trivialExponent ? BigIntegerCalculator.Pow(value._bits, NumericsHelpers.Abs(exponent._sign), modulus._bits) :
                              BigIntegerCalculator.Pow(value._bits, exponent._bits, modulus._bits);

                return new BigInteger(bits, value._sign < 0 && !exponent.IsEven);
            }
        }

        public static BigInteger Pow(BigInteger value, int exponent)
        {
            if (exponent < 0)
                throw new ArgumentOutOfRangeException(nameof(exponent), "SR.ArgumentOutOfRange_MustBeNonNeg");
            //Contract.EndContractBlock();

            value.AssertValid();

            if (exponent == 0)
                return s_bnOneInt;
            if (exponent == 1)
                return value;

            bool trivialValue = value._bits == null;

            if (trivialValue)
            {
                if (value._sign == 1)
                    return value;
                if (value._sign == -1)
                    return (exponent & 1) != 0 ? value : s_bnOneInt;
                if (value._sign == 0)
                    return value;
            }

            uint[] bits = trivialValue
                        ? BigIntegerCalculator.Pow(NumericsHelpers.Abs(value._sign), NumericsHelpers.Abs(exponent))
                        : BigIntegerCalculator.Pow(value._bits, NumericsHelpers.Abs(exponent));

            return new BigInteger(bits, value._sign < 0 && (exponent & 1) != 0);
        }

        public byte[] ToByteArray()
        {
            int sign = _sign;
            if (sign == 0)
            {
                return new byte[] { 0 };
            }

            byte highByte;
            int nonZeroDwordIndex = 0;
            uint highDword;
            uint[] bits = _bits;
            if (bits == null)
            {
                highByte = (byte)((sign < 0) ? 0xff : 0x00);
                highDword = unchecked((uint)sign);
            }
            else if (sign == -1)
            {
                highByte = 0xff;

                // If sign is -1, we will need to two's complement bits.
                // Previously this was accomplished via NumericsHelpers.DangerousMakeTwosComplement(),
                // however, we can do the two's complement on the stack so as to avoid
                // creating a temporary copy of bits just to hold the two's complement.
                // One special case in DangerousMakeTwosComplement() is that if the array
                // is all zeros, then it would allocate a new array with the high-order
                // uint set to 1 (for the carry). In our usage, we will not hit this case
                // because a bits array of all zeros would represent 0, and this case
                // would be encoded as _bits = null and _sign = 0.
                Debug.Assert(bits.Length > 0);
                Debug.Assert(bits[bits.Length - 1] != 0);
                while (bits[nonZeroDwordIndex] == 0U)
                {
                    nonZeroDwordIndex++;
                }

                highDword = ~bits[bits.Length - 1];
                if (bits.Length - 1 == nonZeroDwordIndex)
                {
                    // This will not overflow because highDword is less than or equal to uint.MaxValue - 1.
                    Debug.Assert(highDword <= uint.MaxValue - 1);
                    highDword += 1U;
                }
            }
            else
            {
                Debug.Assert(sign == 1);
                highByte = 0x00;
                highDword = bits[bits.Length - 1];
            }

            byte msb;
            int msbIndex;
            if ((msb = unchecked((byte)(highDword >> 24))) != highByte)
            {
                msbIndex = 3;
            }
            else if ((msb = unchecked((byte)(highDword >> 16))) != highByte)
            {
                msbIndex = 2;
            }
            else if ((msb = unchecked((byte)(highDword >> 8))) != highByte)
            {
                msbIndex = 1;
            }
            else
            {
                msb = unchecked((byte)highDword);
                msbIndex = 0;
            }

            // Ensure high bit is 0 if positive, 1 if negative
            bool needExtraByte = (msb & 0x80) != (highByte & 0x80);
            byte[] bytes;
            int curByte = 0;
            if (bits == null)
            {
                bytes = new byte[msbIndex + 1 + (needExtraByte ? 1 : 0)];
                Debug.Assert(bytes.Length <= 4);
            }
            else
            {
                bytes = new byte[checked(4 * (bits.Length - 1) + msbIndex + 1 + (needExtraByte ? 1 : 0))];

                for (int i = 0; i < bits.Length - 1; i++)
                {
                    uint dword = bits[i];
                    if (sign == -1)
                    {
                        dword = ~dword;
                        if (i <= nonZeroDwordIndex)
                        {
                            dword = unchecked(dword + 1U);
                        }
                    }
                    for (int j = 0; j < 4; j++)
                    {
                        bytes[curByte++] = unchecked((byte)dword);
                        dword >>= 8;
                    }
                }
            }
            for (int j = 0; j <= msbIndex; j++)
            {
                bytes[curByte++] = unchecked((byte)highDword);
                highDword >>= 8;
            }
            if (needExtraByte)
            {
                bytes[bytes.Length - 1] = highByte;
            }
            return bytes;
        }

        internal static int GetDiffLength(uint[] rgu1, uint[] rgu2, int cu)
        {
            for (int iv = cu; --iv >= 0;)
            {
                if (rgu1[iv] != rgu2[iv])
                    return iv + 1;
            }
            return 0;
        }

        [Conditional("DEBUG")]
        private void AssertValid()
        {
            if (_bits != null)
            {
                // _sign must be +1 or -1 when _bits is non-null
                Debug.Assert(_sign == 1 || _sign == -1);
                // _bits must contain at least 1 element or be null
                Debug.Assert(_bits.Length > 0);
                // Wasted space: _bits[0] could have been packed into _sign
                Debug.Assert(_bits.Length > 1 || _bits[0] >= kuMaskHighBit);
                // Wasted space: leading zeros could have been truncated
                Debug.Assert(_bits[_bits.Length - 1] != 0);
            }
            else
            {
                // Int32.MinValue should not be stored in the _sign field
                Debug.Assert(_sign > int.MinValue);
            }
        }

    }
}







//using System;
//using System.Collections;
//using System.Diagnostics;
//using System.Text;
//using System.Threading;

//namespace Bytewizer.TinyCLR.Numerics
//{
//    public struct BigInteger
//    {
//        private const int knMaskHighBit = int.MinValue;
//        private const uint kuMaskHighBit = unchecked((uint)int.MinValue);
//        private const int kcbitUint = 32;
//        private const int kcbitUlong = 64;
//        private const int DecimalScaleFactorMask = 0x00FF0000;
//        private const int DecimalSignMask = unchecked((int)0x80000000);

//        // For values int.MinValue < n <= int.MaxValue, the value is stored in sign
//        // and _bits is null. For all other values, sign is +1 or -1 and the bits are in _bits
//        internal readonly int _sign;
//        internal readonly uint[] _bits;

//        // We have to make a choice of how to represent int.MinValue. This is the one
//        // value that fits in an int, but whose negation does not fit in an int.
//        // We choose to use a large representation, so we're symmetric with respect to negation.
//        private static readonly BigInteger s_bnMinInt = new BigInteger(-1, new uint[] { kuMaskHighBit });
//        private static readonly BigInteger s_bnOneInt = new BigInteger(1);
//        private static readonly BigInteger s_bnZeroInt = new BigInteger(0);
//        private static readonly BigInteger s_bnMinusOneInt = new BigInteger(-1);

//        public BigInteger(int value)
//        {
//            if (value == int.MinValue)
//                this = s_bnMinInt;
//            else
//            {
//                _sign = value;
//                _bits = null;
//            }
//            AssertValid();
//        }

//        public BigInteger(long value)
//        {
//            if (int.MinValue < value && value <= int.MaxValue)
//            {
//                _sign = (int)value;
//                _bits = null;
//            }
//            else if (value == int.MinValue)
//            {
//                this = s_bnMinInt;
//            }
//            else
//            {
//                ulong x = 0;
//                if (value < 0)
//                {
//                    x = unchecked((ulong)-value);
//                    _sign = -1;
//                }
//                else
//                {
//                    x = (ulong)value;
//                    _sign = +1;
//                }

//                if (x <= uint.MaxValue)
//                {
//                    _bits = new uint[1];
//                    _bits[0] = (uint)x;
//                }
//                else
//                {
//                    _bits = new uint[2];
//                    _bits[0] = unchecked((uint)x);
//                    _bits[1] = (uint)(x >> kcbitUint);
//                }
//            }

//            AssertValid();
//        }

//        public BigInteger(byte[] value)
//        {
//            if (value == null)
//                throw new ArgumentNullException(nameof(value));
//            //Contract.EndContractBlock();

//            int byteCount = value.Length;
//            bool isNegative = byteCount > 0 && ((value[byteCount - 1] & 0x80) == 0x80);

//            // Try to conserve space as much as possible by checking for wasted leading byte[] entries 
//            while (byteCount > 0 && value[byteCount - 1] == 0) byteCount--;

//            if (byteCount == 0)
//            {
//                // BigInteger.Zero
//                _sign = 0;
//                _bits = null;
//                AssertValid();
//                return;
//            }

//            if (byteCount <= 4)
//            {
//                if (isNegative)
//                    _sign = unchecked((int)0xffffffff);
//                else
//                    _sign = 0;
//                for (int i = byteCount - 1; i >= 0; i--)
//                {
//                    _sign <<= 8;
//                    _sign |= value[i];
//                }
//                _bits = null;

//                if (_sign < 0 && !isNegative)
//                {
//                    // Int32 overflow
//                    // Example: Int64 value 2362232011 (0xCB, 0xCC, 0xCC, 0x8C, 0x0)
//                    // can be naively packed into 4 bytes (due to the leading 0x0)
//                    // it overflows into the int32 sign bit
//                    _bits = new uint[1];
//                    _bits[0] = (uint)_sign;
//                    _sign = +1;
//                }
//                if (_sign == int.MinValue)
//                    this = s_bnMinInt;
//            }
//            else
//            {
//                int unalignedBytes = byteCount % 4;
//                int dwordCount = byteCount / 4 + (unalignedBytes == 0 ? 0 : 1);
//                bool isZero = true;
//                uint[] val = new uint[dwordCount];

//                // Copy all dwords, except but don't do the last one if it's not a full four bytes
//                int curDword, curByte, byteInDword;
//                curByte = 3;
//                for (curDword = 0; curDword < dwordCount - (unalignedBytes == 0 ? 0 : 1); curDword++)
//                {
//                    byteInDword = 0;
//                    while (byteInDword < 4)
//                    {
//                        if (value[curByte] != 0x00) isZero = false;
//                        val[curDword] <<= 8;
//                        val[curDword] |= value[curByte];
//                        curByte--;
//                        byteInDword++;
//                    }
//                    curByte += 8;
//                }

//                // Copy the last dword specially if it's not aligned
//                if (unalignedBytes != 0)
//                {
//                    if (isNegative) val[dwordCount - 1] = 0xffffffff;
//                    for (curByte = byteCount - 1; curByte >= byteCount - unalignedBytes; curByte--)
//                    {
//                        if (value[curByte] != 0x00) isZero = false;
//                        val[curDword] <<= 8;
//                        val[curDword] |= value[curByte];
//                    }
//                }

//                if (isZero)
//                {
//                    this = s_bnZeroInt;
//                }
//                else if (isNegative)
//                {
//                    NumericsHelpers.DangerousMakeTwosComplement(val); // Mutates val

//                    // Pack _bits to remove any wasted space after the twos complement
//                    int len = val.Length;
//                    while (len > 0 && val[len - 1] == 0)
//                        len--;
//                    if (len == 1 && ((int)(val[0])) > 0)
//                    {
//                        if (val[0] == 1 /* abs(-1) */)
//                        {
//                            this = s_bnMinusOneInt;
//                        }
//                        else if (val[0] == kuMaskHighBit /* abs(Int32.MinValue) */)
//                        {
//                            this = s_bnMinInt;
//                        }
//                        else
//                        {
//                            _sign = (-1) * ((int)val[0]);
//                            _bits = null;
//                        }
//                    }
//                    else if (len != val.Length)
//                    {
//                        _sign = -1;
//                        _bits = new uint[len];
//                        Array.Copy(val, 0, _bits, 0, len);
//                    }
//                    else
//                    {
//                        _sign = -1;
//                        _bits = val;
//                    }
//                }
//                else
//                {
//                    _sign = +1;
//                    _bits = val;
//                }
//            }
//            AssertValid();
//        }

//        internal BigInteger(int n, uint[] rgu)
//        {
//            _sign = n;
//            _bits = rgu;
//            AssertValid();
//        }

//        private BigInteger(uint[] value, bool negative)
//        {
//            int len;

//            // Try to conserve space as much as possible by checking for wasted leading span entries
//            // sometimes the span has leading zeros from bit manipulation operations & and ^
//            for (len = value.Length; len > 0 && value[len - 1] == 0; len--) ;

//            if (len == 0)
//            {
//                this = s_bnZeroInt;
//            }
//            else if (len == 1 && value[0] < kuMaskHighBit)
//            {
//                // Values like (Int32.MaxValue+1) are stored as "0x80000000" and as such cannot be packed into _sign
//                _sign = negative ? -(int)value[0] : (int)value[0];
//                _bits = null;
//                if (_sign == int.MinValue)
//                {
//                    // Although Int32.MinValue fits in _sign, we represent this case differently for negate
//                    this = s_bnMinInt;
//                }
//            }
//            else
//            {
//                _sign = negative ? -1 : +1;
//                _bits = value;
//            }
//            AssertValid();
//        }

//        public static BigInteger Abs(BigInteger value)
//        {
//            return (value >= Zero) ? value : -value;
//        }

//        public static BigInteger operator -(BigInteger value)
//        {
//            value.AssertValid();
//            return new BigInteger(-value._sign, value._bits);
//        }

//        public int CompareTo(BigInteger other)
//        {
//            AssertValid();
//            other.AssertValid();

//            if ((_sign ^ other._sign) < 0)
//            {
//                // Different signs, so the comparison is easy.
//                return _sign < 0 ? -1 : +1;
//            }

//            // Same signs
//            if (_bits == null)
//            {
//                if (other._bits == null)
//                    return _sign < other._sign ? -1 : _sign > other._sign ? +1 : 0;
//                return -other._sign;
//            }
//            int cuThis, cuOther;
//            if (other._bits == null || (cuThis = _bits.Length) > (cuOther = other._bits.Length))
//                return _sign;
//            if (cuThis < cuOther)
//                return -_sign;

//            int cuDiff = GetDiffLength(_bits, other._bits, cuThis);
//            if (cuDiff == 0)
//                return 0;
//            return _bits[cuDiff - 1] < other._bits[cuDiff - 1] ? -_sign : _sign;
//        }

//        internal static int GetDiffLength(uint[] rgu1, uint[] rgu2, int cu)
//        {
//            for (int iv = cu; --iv >= 0;)
//            {
//                if (rgu1[iv] != rgu2[iv])
//                    return iv + 1;
//            }
//            return 0;
//        }

//        public static bool operator <(BigInteger left, BigInteger right)
//        {
//            return left.CompareTo(right) < 0;
//        }

//        public static bool operator <=(BigInteger left, BigInteger right)
//        {
//            return left.CompareTo(right) <= 0;
//        }

//        public static bool operator >(BigInteger left, BigInteger right)
//        {
//            return left.CompareTo(right) > 0;
//        }

//        public static bool operator >=(BigInteger left, BigInteger right)
//        {
//            return left.CompareTo(right) >= 0;
//        }

//        public static bool operator ==(BigInteger left, BigInteger right)
//        {
//            return left.Equals(right);
//        }

//        public static bool operator !=(BigInteger left, BigInteger right)
//        {
//            return !left.Equals(right);
//        }

//        public static BigInteger Zero { get { return s_bnZeroInt; } }

//        public static BigInteger One { get { return s_bnOneInt; } }

//        public static BigInteger MinusOne { get { return s_bnMinusOneInt; } }

//        public bool IsPowerOfTwo
//        {
//            get
//            {
//                AssertValid();

//                if (_bits == null)
//                    return (_sign & (_sign - 1)) == 0 && _sign != 0;

//                if (_sign != 1)
//                    return false;
//                int iu = _bits.Length - 1;
//                if ((_bits[iu] & (_bits[iu] - 1)) != 0)
//                    return false;
//                while (--iu >= 0)
//                {
//                    if (_bits[iu] != 0)
//                        return false;
//                }
//                return true;
//            }
//        }

//        public bool IsZero { get { AssertValid(); return _sign == 0; } }

//        public bool IsOne { get { AssertValid(); return _sign == 1 && _bits == null; } }

//        public bool IsEven { get { AssertValid(); return _bits == null ? (_sign & 1) == 0 : (_bits[0] & 1) == 0; } }

//        public int Sign
//        {
//            get { AssertValid(); return (_sign >> (kcbitUint - 1)) - (-_sign >> (kcbitUint - 1)); }
//        }

//        public static BigInteger ModPow(BigInteger value, BigInteger exponent, BigInteger modulus)
//        {
//            if (exponent.Sign < 0)
//                throw new ArgumentOutOfRangeException(nameof(exponent), "SR.ArgumentOutOfRange_MustBeNonNeg");
//            //Contract.EndContractBlock();

//            value.AssertValid();
//            exponent.AssertValid();
//            modulus.AssertValid();

//            bool trivialValue = value._bits == null;
//            bool trivialExponent = exponent._bits == null;
//            bool trivialModulus = modulus._bits == null;

//            if (trivialModulus)
//            {
//                return new BigInteger();

//                //uint bits = trivialValue && trivialExponent ? BigIntegerCalculator.Pow(NumericsHelpers.Abs(value._sign), NumericsHelpers.Abs(exponent._sign), NumericsHelpers.Abs(modulus._sign)) :
//                //            trivialValue ? BigIntegerCalculator.Pow(NumericsHelpers.Abs(value._sign), exponent._bits, NumericsHelpers.Abs(modulus._sign)) :
//                //            trivialExponent ? BigIntegerCalculator.Pow(value._bits, NumericsHelpers.Abs(exponent._sign), NumericsHelpers.Abs(modulus._sign)) :
//                //            BigIntegerCalculator.Pow(value._bits, exponent._bits, NumericsHelpers.Abs(modulus._sign));

//                //return value._sign < 0 && !exponent.IsEven ? -1 * bits : bits;
//            }
//            else
//            {
//                uint[] bits = trivialValue && trivialExponent ? BigIntegerCalculator.Pow(NumericsHelpers.Abs(value._sign), NumericsHelpers.Abs(exponent._sign), modulus._bits) :
//                              trivialValue ? BigIntegerCalculator.Pow(NumericsHelpers.Abs(value._sign), exponent._bits, modulus._bits) :
//                              trivialExponent ? BigIntegerCalculator.Pow(value._bits, NumericsHelpers.Abs(exponent._sign), modulus._bits) :
//                              BigIntegerCalculator.Pow(value._bits, exponent._bits, modulus._bits);

//                return new BigInteger(bits, value._sign < 0 && !exponent.IsEven);
//            }
//        }

//        public static implicit operator BigInteger(long value)
//        {
//            return new BigInteger(value);
//        }

//        public byte[] ToByteArray()
//        {
//            int sign = _sign;
//            if (sign == 0)
//            {
//                return new byte[] { 0 };
//            }

//            byte highByte;
//            int nonZeroDwordIndex = 0;
//            uint highDword;
//            uint[] bits = _bits;
//            if (bits == null)
//            {
//                highByte = (byte)((sign < 0) ? 0xff : 0x00);
//                highDword = unchecked((uint)sign);
//            }
//            else if (sign == -1)
//            {
//                highByte = 0xff;

//                // If sign is -1, we will need to two's complement bits.
//                // Previously this was accomplished via NumericsHelpers.DangerousMakeTwosComplement(),
//                // however, we can do the two's complement on the stack so as to avoid
//                // creating a temporary copy of bits just to hold the two's complement.
//                // One special case in DangerousMakeTwosComplement() is that if the array
//                // is all zeros, then it would allocate a new array with the high-order
//                // uint set to 1 (for the carry). In our usage, we will not hit this case
//                // because a bits array of all zeros would represent 0, and this case
//                // would be encoded as _bits = null and _sign = 0.
//                Debug.Assert(bits.Length > 0);
//                Debug.Assert(bits[bits.Length - 1] != 0);
//                while (bits[nonZeroDwordIndex] == 0U)
//                {
//                    nonZeroDwordIndex++;
//                }

//                highDword = ~bits[bits.Length - 1];
//                if (bits.Length - 1 == nonZeroDwordIndex)
//                {
//                    // This will not overflow because highDword is less than or equal to uint.MaxValue - 1.
//                    Debug.Assert(highDword <= uint.MaxValue - 1);
//                    highDword += 1U;
//                }
//            }
//            else
//            {
//                Debug.Assert(sign == 1);
//                highByte = 0x00;
//                highDword = bits[bits.Length - 1];
//            }

//            byte msb;
//            int msbIndex;
//            if ((msb = unchecked((byte)(highDword >> 24))) != highByte)
//            {
//                msbIndex = 3;
//            }
//            else if ((msb = unchecked((byte)(highDword >> 16))) != highByte)
//            {
//                msbIndex = 2;
//            }
//            else if ((msb = unchecked((byte)(highDword >> 8))) != highByte)
//            {
//                msbIndex = 1;
//            }
//            else
//            {
//                msb = unchecked((byte)highDword);
//                msbIndex = 0;
//            }

//            // Ensure high bit is 0 if positive, 1 if negative
//            bool needExtraByte = (msb & 0x80) != (highByte & 0x80);
//            byte[] bytes;
//            int curByte = 0;
//            if (bits == null)
//            {
//                bytes = new byte[msbIndex + 1 + (needExtraByte ? 1 : 0)];
//                Debug.Assert(bytes.Length <= 4);
//            }
//            else
//            {
//                bytes = new byte[checked(4 * (bits.Length - 1) + msbIndex + 1 + (needExtraByte ? 1 : 0))];

//                for (int i = 0; i < bits.Length - 1; i++)
//                {
//                    uint dword = bits[i];
//                    if (sign == -1)
//                    {
//                        dword = ~dword;
//                        if (i <= nonZeroDwordIndex)
//                        {
//                            dword = unchecked(dword + 1U);
//                        }
//                    }
//                    for (int j = 0; j < 4; j++)
//                    {
//                        bytes[curByte++] = unchecked((byte)dword);
//                        dword >>= 8;
//                    }
//                }
//            }
//            for (int j = 0; j <= msbIndex; j++)
//            {
//                bytes[curByte++] = unchecked((byte)highDword);
//                highDword >>= 8;
//            }
//            if (needExtraByte)
//            {
//                bytes[bytes.Length - 1] = highByte;
//            }
//            return bytes;
//        }

//        [Conditional("DEBUG")]
//        private void AssertValid()
//        {
//            if (_bits != null)
//            {
//                // _sign must be +1 or -1 when _bits is non-null
//                Debug.Assert(_sign == 1 || _sign == -1);
//                // _bits must contain at least 1 element or be null
//                Debug.Assert(_bits.Length > 0);
//                // Wasted space: _bits[0] could have been packed into _sign
//                Debug.Assert(_bits.Length > 1 || _bits[0] >= kuMaskHighBit);
//                // Wasted space: leading zeros could have been truncated
//                Debug.Assert(_bits[_bits.Length - 1] != 0);
//            }
//            else
//            {
//                // Int32.MinValue should not be stored in the _sign field
//                Debug.Assert(_sign > int.MinValue);
//            }
//        }


//        //public static implicit operator BigInteger(byte value)
//        //{
//        //    return new BigInteger(value);
//        //}

//        //public static implicit operator BigInteger(sbyte value)
//        //{
//        //    return new BigInteger(value);
//        //}

//        //public static implicit operator BigInteger(short value)
//        //{
//        //    return new BigInteger(value);
//        //}

//        //public static implicit operator BigInteger(ushort value)
//        //{
//        //    return new BigInteger(value);
//        //}

//        //public static implicit operator BigInteger(int value)
//        //{
//        //    return new BigInteger(value);
//        //}

//        //public static explicit operator byte(BigInteger value)
//        //{
//        //    return checked((byte)((int)value));
//        //}

//        //public static explicit operator sbyte(BigInteger value)
//        //{
//        //    return checked((sbyte)((int)value));
//        //}

//        //public static explicit operator short(BigInteger value)
//        //{
//        //    return checked((short)((int)value));
//        //}

//        //public static explicit operator ushort(BigInteger value)
//        //{
//        //    return checked((ushort)((int)value));
//        //}

//        //public static explicit operator int(BigInteger value)
//        //{
//        //    value.AssertValid();
//        //    if (value._bits == null)
//        //    {
//        //        return value._sign;  // Value packed into int32 sign
//        //    }
//        //    if (value._bits.Length > 1)
//        //    {
//        //        // More than 32 bits
//        //        throw new OverflowException("SR.Overflow_Int32");
//        //    }
//        //    if (value._sign > 0)
//        //    {
//        //        return checked((int)value._bits[0]);
//        //    }
//        //    if (value._bits[0] > kuMaskHighBit)
//        //    {
//        //        // Value > Int32.MinValue
//        //        throw new OverflowException("SR.Overflow_Int32");
//        //    }
//        //    return unchecked(-(int)value._bits[0]);
//        //}
//    }
//}
